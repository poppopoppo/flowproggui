print_string "HELLO WORLD \n";
flush stdout
