./SHX main_sh.mdls syntax.mdls start_sh.mdls 
